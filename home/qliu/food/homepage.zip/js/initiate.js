// Display Options 
var title = '', description = '', image = 'url', video = '', primary_key = 'id'; 
var item_types = {'author': 'text','name': 'text','url': 'video'}; 
var display_items = ['url']; 

// Recommender Info 
var recommender_name = 'foodporn';
 var client_key = 'IaS68IUq3yVJ9vm9B47qZFKlA';
 var homepage = 'http://localhost/kibitz-demo/home/qliu/food';
 var creator_name = 'qliu'; 
 var repo_name = 'food'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 5; 
