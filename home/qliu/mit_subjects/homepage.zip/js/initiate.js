// Display Options 
var title = 'subject_title', description = 'subject_id', image = '', video = '', primary_key = 'subject_id'; 
var item_types = {'subject_id': 'text','subject_title': 'text','offer_department': 'text','term_code': 'text'}; 
var display_items = ['term_code','offer_department','subject_title','subject_id']; 

// Recommender Info 
var recommender_name = 'subject_by_term';
 var client_key = 'Rb5Uiwa8SlbYqWc0WAwKeK2ou';
 var homepage = 'http://localhost/kibitz-demo/home/qliu/mit_subjects';
 var creator_name = 'qliu'; 
 var repo_name = 'mit_subjects'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
