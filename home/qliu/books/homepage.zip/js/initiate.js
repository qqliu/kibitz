// Display Options 
var title = 'booktitle', description = 'bookauthor', image = 'imageurlm', video = '', primary_key = 'isbn'; 
var item_types = {'bookauthor': 'text','imageurlm': 'video','booktitle': 'text'}; 
var display_items = ['booktitle','bookauthor','imageurlm']; 

// Recommender Info 
var recommender_name = 'bxbooks';
 var client_key = 'nPKnn1WJ6ds2nXjRvEDaJaz7M';
 var homepage = 'http://quanquan.scripts.mit.edu/books/again/';
 var creator_name = 'qliu'; 
 var repo_name = 'books'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
