// Display Options 
var title = 'title', description = 'no_kibitz_description', image = 'no_kibitz_image', video = 'no_kibitz_video', primary_key = 'title'; 
var item_types = {'title': 'text'}; 
var display_items = ['title']; 

// Recommender Info 
var recommender_name = 'board_games';
 var client_key = 'imBLeTjVpFEZNndVfp5Q7AO1p';
 var creator_name = 'q2liu'; 
 var repo_name = 'boardgames'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
