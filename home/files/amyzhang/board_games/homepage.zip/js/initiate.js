// Display Options 
var title = 'title', description = 'no_kibitz_description', image = 'no_kibitz_image', video = 'no_kibitz_video', primary_key = 'title'; 
var item_types = {'title': 'text'}; 
var display_items = ['title']; 

// Recommender Info 
var recommender_name = 'board_games';
 var client_key = '34mqnsP3ah6QSxwKe6AXOK2Sv';
 var creator_name = 'amyzhang'; 
 var repo_name = 'board_games'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
