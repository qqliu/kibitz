// Display Options 
var title = 'title', description = 'avg_rating', image = '', video = '', primary_key = 'title'; 
var item_types = {'geek_rating': 'number','title': 'text','board_game_rank': 'number'}; 
var display_items = ['board_game_rank','geek_rating','title','avg_rating']; 

// Recommender Info 
var recommender_name = 'https_boardgamegeek_com_browse_boardgame';
 var client_key = 'G8X3uYcB12Lc7ydAkdAbtqnbF';
 var creator_name = 'q2liu'; 
 var repo_name = 'board_games'; 

// Rating Customization 
var num_recs = 5; 
var maxRatingVal = 5; 
