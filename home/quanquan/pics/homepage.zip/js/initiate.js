// Display Options 
var title = 'no_kibitz_title', description = 'no_kibitz_description', image = 'img', video = undefined; 
var item_types = {'img': 'video'}; 
var display_items = ['img']; 

// Recommender Info 
var recommender_name = 'pics';
 var client_key = 'h3kzj7MxUTEFfvwUJPImPAiBa';
 var homepage = 'quanquan/pics';
 var creator_name = 'quanquan'; 
 var repo_name = 'pics'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
