// Display Options 
var title = 'name', description = 'descript', image = 'img', video = undefined; 
var item_types = {'name': 'text','img': 'video','descript': 'text'}; 
var display_items = ['name','descript','img']; 

// Recommender Info 
var recommender_name = 'demo_file';
 var client_key = 'LsGQjPXK8yQc4nMnJkuB14YJL';
 var homepage = 'quanquan/quanquan_movies';
 var creator_name = 'quanquan'; 
 var repo_name = 'quanquan_movies'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
