// Display Options 
var title = 'ny', description = 'new_york', image = 'col8363710', video = 'col8363710', primary_key = 'new_york'; 
var item_types = {'col8363710': 'text','new_york': 'text','kibitz_generated_id': 'text','ny': 'text'}; 
var display_items = ['kibitz_generated_id','ny','new_york','col8363710','col8363710']; 

// Recommender Info 
var recommender_name = 'top5000population';
 var client_key = 'l9wI61qHXgcxnImffeNERoPB4';
 var homepage = 'http://localhost/kibitz-demo/home/quanquan/quanquan_cities_demo';
 var creator_name = 'quanquan'; 
 var repo_name = 'quanquan_cities_demo'; 

// Rating Customization 
var num_recs = 5; 
var maxRatingVal = 5; 
