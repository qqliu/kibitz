// Display Options 
var title = 'title', description = 'author', image = 'no_kibitz_image', video = undefined; 
var item_types = {'author': 'text','title': 'text'}; 
var display_items = ['title','author']; 

// Recommender Info 
var recommender_name = 'readinglistsbbc';
 var client_key = 'x4wM4Twdt6bUgH1z4b9of7vL8';
 var homepage = 'quanquan/books_with_rating';
 var creator_name = 'quanquan'; 
 var repo_name = 'books_with_rating'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
