// Display Options 
var title = 'title', description = 'author', image = 'no_kibitz_image', video = undefined; 
var item_types = {'author': 'text','title': 'text'}; 
var display_items = ['title','author']; 

// Recommender Info 
var recommender_name = 'readinglistsbbc';
 var client_key = 'NQotfbxfCDhI7rlHjQntXhAsD';
 var homepage = 'quanquan/quanquan_books_demo';
 var creator_name = 'quanquan'; 
 var repo_name = 'quanquan_books_demo'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
