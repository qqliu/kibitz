// Display Options 
var title = 'title', description = 'no_kibitz_description', image = 'image', video = undefined; 
var item_types = {title: 'text',image: 'video'}; 
var display_items = [title,image]; 

// Recommender Info 
var recommender_name = 'qqb2';
 var client_key = 'YXkI8u1q4XGahkAx5BNOFHWL7';
 var homepage = 'quanquan/lotsofdata';
 var creator_name = 'quanquan'; 
 var repo_name = 'lotsofdata'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
