// Display Options 
var title = 'name', description = '', image = '', video = '', primary_key = 'name'; 
var item_types = {'link': 'html','name': 'text'}; 
var display_items = ['link','name']; 

// Recommender Info 
var recommender_name = 'moviesdemo';
 var client_key = 'R6MlrWXGYH21Uwu3ocXKxtiFQ';
 var homepage = 'http://localhost/kibitz-demo/home/quanquan/quanquan_movies_demo';
 var creator_name = 'quanquan'; 
 var repo_name = 'quanquan_movies_demo'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
