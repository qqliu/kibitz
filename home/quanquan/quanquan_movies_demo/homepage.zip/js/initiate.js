// Display Options 
var title = 'name', description = 'descript', image = 'img', video = undefined; 
var item_types = {'name': 'text','img': 'video','descript': 'text'}; 
var display_items = ['name','descript','img']; 

// Recommender Info 
var recommender_name = 'moviesdemo';
 var client_key = 'oFSDt9wb6j0DASoXHEA3gBp74';
 var homepage = 'quanquan/quanquan_movies_demo';
 var creator_name = 'quanquan'; 
 var repo_name = 'quanquan_movies_demo'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
