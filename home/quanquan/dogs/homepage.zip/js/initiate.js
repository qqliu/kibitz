// Display Options 
var title = 'col1', description = 'no_kibitz_description', image = 'no_kibitz_image', video = undefined, primary_key = 'col1'; 
var item_types = {'col1': 'text'}; 
var display_items = ['col1']; 

// Recommender Info 
var recommender_name = 'dogsbreedreferencesheet1';
 var client_key = 'GCHMiUtCrD3V8pIeGDCohs6cE';
 var homepage = 'http://localhost/kibitz-demo/home/quanquan/dogs';
 var creator_name = 'quanquan'; 
 var repo_name = 'dogs'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
