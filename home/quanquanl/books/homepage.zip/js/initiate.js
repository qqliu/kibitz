// Display Options 
var title = 'title', description = 'author', image = 'no_kibitz_image', video = undefined, primary_key = 'title'; 
var item_types = {'author': 'text','title': 'text'}; 
var display_items = ['title','author']; 

// Recommender Info 
var recommender_name = 'readinglistsbbc';
 var client_key = 'erd3EYH5aSDzWaW3m3xiTp1qb';
 var homepage = 'http://localhost/kibitz-demo/home/quanquanl/books';
 var creator_name = 'quanquanl'; 
 var repo_name = 'books'; 

// Rating Customization 
var num_recs = 10; 
var maxRatingVal = 10; 
